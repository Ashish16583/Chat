const socket = io();
let username, avatar, room;

function joinChat() {
  username = document.getElementById('username').value;
  avatar = document.getElementById('avatar').value;
  room = document.getElementById('room').value;

  if (!username || !room) return alert("Username and room are required");

  document.getElementById('auth').classList.add('hidden');
  document.getElementById('chat').classList.remove('hidden');
  document.getElementById('room-title').innerText = `Room: ${room}`;

  socket.emit('joinRoom', { username, avatar, room });
}

function sendMessage() {
  const message = document.getElementById('message').value;
  if (message) {
    socket.emit('chatMessage', message);
    document.getElementById('message').value = '';
  }
}

function notifyTyping() {
  socket.emit('typing');
}

socket.on('message', ({ username, avatar, text, time }) => {
  const msgDiv = document.createElement('div');
  msgDiv.innerHTML = `
    <img src="${avatar || 'https://via.placeholder.com/30'}" class="avatar" />
    <strong>${username}</strong>: ${text}
    <span class="timestamp">${time}</span>
  `;
  document.getElementById('messages').appendChild(msgDiv);
});

socket.on('typing', (username) => {
  document.getElementById('typing').innerText = `${username} is typing...`;
  setTimeout(() => {
    document.getElementById('typing').innerText = '';
  }, 2000);
});
